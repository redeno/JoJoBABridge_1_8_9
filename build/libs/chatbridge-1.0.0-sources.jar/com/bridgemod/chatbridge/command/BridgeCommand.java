package com.bridgemod.chatbridge.command;

import com.bridgemod.chatbridge.ChatBridgeMod;
import com.bridgemod.chatbridge.gui.BridgeGui;
import net.minecraft.client.Minecraft;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;

import java.util.List;

public class BridgeCommand extends CommandBase {
    
    @Override
    public String func_71517_b() {
        return "bridge";
    }
    
    @Override
    public String func_71518_a(ICommandSender sender) {
        return "/bridge - Открыть меню настроек чат бриджа";
    }
    
    @Override
    public int func_82362_a() {
        return 0;
    }
    
    @Override
    public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
        if (Minecraft.func_71410_x().field_71441_e != null) {
            Minecraft.func_71410_x().func_147108_a(new BridgeGui());
        }
    }
    
    @Override
    public List<String> func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
        return null;
    }
}