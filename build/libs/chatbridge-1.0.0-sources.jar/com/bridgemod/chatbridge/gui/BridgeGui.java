package com.bridgemod.chatbridge.gui;

import com.bridgemod.chatbridge.ChatBridgeMod;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import net.minecraft.client.resources.I18n;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class BridgeGui extends GuiScreen {
    private BridgeToggleButton bridgeToggleButton;
    private GuiButton doneButton;
    
    @Override
    public void func_73866_w_() {
        super.func_73866_w_();
        
        this.field_146292_n.clear();
        
        // Создаем кнопку для включения/выключения чат бриджа
        boolean currentState = ChatBridgeMod.instance.getConfigManager().isBridgeChatEnabled();
        bridgeToggleButton = new BridgeToggleButton(1, 
            this.field_146294_l / 2 - 75, 
            this.field_146295_m / 2 - 10, 
            150, 20, 
            currentState);
        
        this.field_146292_n.add(bridgeToggleButton);
        
        // Кнопка "Готово"
        doneButton = new GuiButton(2, this.field_146294_l / 2 - 50, this.field_146295_m / 2 + 30, 100, 20, "Готово");
        this.field_146292_n.add(doneButton);
    }
    
    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k == 1) { // Кнопка переключения
            bridgeToggleButton.toggle();
        } else if (button.field_146127_k == 2) { // Кнопка "Готово"
            this.field_146297_k.func_147108_a(null);
        }
    }
    
    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        
        // Заголовок
        this.func_73732_a(this.field_146289_q, "Настройки Чат Бриджа", 
            this.field_146294_l / 2, this.field_146295_m / 2 - 50, 0xFFFFFF);
        
        // Описание
        String description = "Включите чат бридж для общения с другими игроками, у которых установлен мод";
        this.func_73732_a(this.field_146289_q, description, 
            this.field_146294_l / 2, this.field_146295_m / 2 - 35, 0xAAAAAA);
        
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
    
    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            this.field_146297_k.func_147108_a(null);
        }
    }
    
    @Override
    public boolean func_73868_f() {
        return false;
    }
    
    // Кастомная кнопка для переключения чат бриджа
    private class BridgeToggleButton extends GuiButton {
        private boolean enabled;
        
        public BridgeToggleButton(int id, int x, int y, int width, int height, boolean enabled) {
            super(id, x, y, width, height, "");
            this.enabled = enabled;
            updateDisplayString();
        }
        
        public void toggle() {
            this.enabled = !this.enabled;
            ChatBridgeMod.instance.getConfigManager().setBridgeChatEnabled(this.enabled);
            updateDisplayString();
        }
        
        private void updateDisplayString() {
            this.field_146126_j = "Чат Бридж: " + (this.enabled ? "ВКЛ" : "ВЫКЛ");
        }
        
        public boolean isEnabled() {
            return this.enabled;
        }
    }
}